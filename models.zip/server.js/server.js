const express = require("express");
const cors = require("cors");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const { Pool } = require("pg");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 5002;

// ✅ Create necessary directories
const createDirectory = (dirPath) => {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
        console.log(`📂 Created directory: ${dirPath}`);
    }
};

const uploadsDir = path.join(__dirname, "uploads");
const assignmentsDir = path.join(uploadsDir, "assignments");
const submissionsDir = path.join(uploadsDir, "submissions");
const reviewCoursesDir = path.join(uploadsDir, "review_courses");

createDirectory(assignmentsDir);
createDirectory(submissionsDir);
createDirectory(reviewCoursesDir);

// ✅ Middleware Setup
app.use(express.json());
app.use(cors());
app.use("/uploads", express.static(uploadsDir)); // Serve static files

// ✅ PostgreSQL Connection
const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: 5432,
});

pool.connect()
    .then(() => console.log("✅ Connected to PostgreSQL"))
    .catch(err => console.error("❌ Database connection error:", err));

// ✅ JWT Middleware for Authentication
const verifyToken = (req, res, next) => {
    const token = req.header("Authorization")?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "Unauthorized" });

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        res.status(403).json({ error: "Invalid token" });
    }
};

// ✅ Middleware to verify Admin
const verifyAdmin = (req, res, next) => {
    if (req.user.role !== "admin") {
        return res.status(403).json({ error: "Unauthorized access" });
    }
    next();
};

// ✅ Multer Configuration for Assignments & Submissions
const uploadAssignment = multer({ storage: multer.diskStorage({
    destination: assignmentsDir,
    filename: (req, file, cb) => cb(null, file.originalname)
}) });

const uploadSubmission = multer({ storage: multer.diskStorage({
    destination: submissionsDir,
    filename: (req, file, cb) => cb(null, file.originalname)
}) });

// ✅ Upload Assignments (Admin Only)
app.post("/api/assignments/upload", verifyToken, verifyAdmin, uploadAssignment.single("file"), async (req, res) => {
    const { title } = req.body;
    const filePath = req.file ? `/uploads/assignments/${req.file.filename}` : null;

    if (!filePath) {
        return res.status(400).json({ error: "File upload required" });
    }

    try {
        const result = await pool.query(
            `INSERT INTO assignments (title, file_url, uploaded_by) VALUES ($1, $2, $3) RETURNING *`,
            [title, filePath, req.user.userId]
        );
        res.json({ message: "Assignment uploaded successfully!", assignment: result.rows[0] });
    } catch (error) {
        console.error("❌ Error uploading assignment:", error);
        res.status(500).json({ error: "Server error" });
    }
});

// ✅ Fetch Assignments
app.get("/api/assignments", async (req, res) => {
    try {
        const result = await pool.query(`SELECT * FROM assignments ORDER BY id DESC`);
        res.json(result.rows);
    } catch (error) {
        console.error("❌ Error fetching assignments:", error);
        res.status(500).json({ error: "Server error" });
    }
});

// ✅ Upload Student Submissions
app.post("/api/submissions/upload", uploadSubmission.single("file"), async (req, res) => {
    const { student_name } = req.body;
    const filePath = req.file ? `/uploads/submissions/${req.file.filename}` : null;

    if (!filePath) {
        return res.status(400).json({ error: "File upload required" });
    }

    try {
        await pool.query(
            `INSERT INTO submissions (student_name, file_url) VALUES ($1, $2)`,
            [student_name, filePath]
        );
        res.json({ message: "Submission uploaded successfully!" });
    } catch (error) {
        console.error("❌ Error uploading submission:", error);
        res.status(500).json({ error: "Server error" });
    }
});

// ✅ Fetch Student Submissions
app.get("/api/submissions", async (req, res) => {
    try {
        const result = await pool.query(`SELECT * FROM submissions ORDER BY upload_date DESC`);
        res.json(result.rows);
    } catch (error) {
        console.error("❌ Error fetching submissions:", error);
        res.status(500).json({ error: "Server error" });
    }
});

// ✅ Multer Configuration for Video Uploads
const uploadVideo = multer({ storage: multer.diskStorage({
    destination: reviewCoursesDir,
    filename: (req, file, cb) => cb(null, file.originalname)
}) });

// ✅ Fetch Review Courses (Videos)
app.get('/api/review-courses', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM review_courses ORDER BY id DESC');
        res.json(result.rows);
    } catch (error) {
        console.error('❌ Error fetching videos:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// ✅ Upload Videos (Admin Only)
app.post("/api/review-courses/upload", verifyToken, verifyAdmin, uploadVideo.single("video"), async (req, res) => {
    const { title } = req.body;
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });

    const filePath = `/uploads/review_courses/${req.file.filename}`;

    try {
        await pool.query("INSERT INTO review_courses (title, video_path) VALUES ($1, $2)", [title, filePath]);
        res.json({ message: "✅ Video uploaded successfully!" });
    } catch (error) {
        console.error("❌ Error uploading video:", error);
        res.status(500).json({ error: "Server error" });
    }
});

// ✅ Delete Video (Admin Only + Remove File)
app.delete("/api/review-courses/delete/:id", verifyToken, verifyAdmin, async (req, res) => {
    const videoId = req.params.id;

    try {
        const result = await pool.query("SELECT video_path FROM review_courses WHERE id = $1", [videoId]);

        if (result.rows.length === 0) {
            return res.status(404).json({ error: "Video not found" });
        }

        const filePath = path.join(__dirname, result.rows[0].video_path);
        
        fs.unlink(filePath, async (err) => {
            if (err) console.error("❌ Error deleting file:", err);

            await pool.query("DELETE FROM review_courses WHERE id = $1", [videoId]);
            res.json({ message: "Video deleted successfully!" });
        });

    } catch (error) {
        console.error("❌ Error deleting video:", error);
        res.status(500).json({ error: "Server error" });
    }
});

// ✅ Start Server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
